import './JS/lib/util.ym.js'
import dr from './JS/lib/drpy.min.js'
 
__JS_SPIDER__ = dr.DRPY()